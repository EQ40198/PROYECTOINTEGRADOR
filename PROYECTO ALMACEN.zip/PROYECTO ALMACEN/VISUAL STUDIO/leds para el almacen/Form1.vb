﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Button1.BackColor = Color.Red Then
            Button1.BackColor = Color.Lime
            SerialPort1.Write("a")
        Else
            Button1.BackColor = Color.Red
            SerialPort1.Write("b")
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SerialPort1.Open()
        apagados()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.BackColor = Color.Red Then
            Button2.BackColor = Color.Lime
            SerialPort1.Write("c")
        Else
            Button2.BackColor = Color.Red
            SerialPort1.Write("d")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Button3.BackColor = Color.Red Then
            Button3.BackColor = Color.Lime
            SerialPort1.Write("e")
        Else
            Button3.BackColor = Color.Red
            SerialPort1.Write("f")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Button4.BackColor = Color.Red Then
            Button4.BackColor = Color.Lime
            SerialPort1.Write("g")
        Else
            Button4.BackColor = Color.Red
            SerialPort1.Write("h")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If Button5.BackColor = Color.Red Then
            Button5.BackColor = Color.Lime
            SerialPort1.Write("i")
        Else
            Button5.BackColor = Color.Red
            SerialPort1.Write("j")
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If Button6.BackColor = Color.Red Then
            Button6.BackColor = Color.Lime
            SerialPort1.Write("k")
        Else
            Button6.BackColor = Color.Red
            SerialPort1.Write("l")
        End If
    End Sub

 

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If Button8.BackColor = Color.Red Then
            Button8.BackColor = Color.Lime
            SerialPort1.Write("o")
        Else
            Button8.BackColor = Color.Red
            SerialPort1.Write("p")
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If Button9.BackColor = Color.Red Then
            Button9.BackColor = Color.Lime
            SerialPort1.Write("q")
        Else
            Button9.BackColor = Color.Red
            SerialPort1.Write("r")
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If Button10.BackColor = Color.Red Then
            Button10.BackColor = Color.Lime
            SerialPort1.Write("s")
        Else
            Button10.BackColor = Color.Red
            SerialPort1.Write("t")
        End If
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Button1.BackColor = Color.Lime
        SerialPort1.Write("a")
        Button2.BackColor = Color.Lime
        SerialPort1.Write("c")
        Button3.BackColor = Color.Lime
        SerialPort1.Write("e")
        Button4.BackColor = Color.Lime
        SerialPort1.Write("g")
        Button5.BackColor = Color.Lime
        SerialPort1.Write("i")
        Button6.BackColor = Color.Lime
        SerialPort1.Write("k")
        Button8.BackColor = Color.Lime
        SerialPort1.Write("o")
        Button9.BackColor = Color.Lime
        SerialPort1.Write("q")
        Button10.BackColor = Color.Lime
        SerialPort1.Write("s")
        Button10.BackColor = Color.Lime
        SerialPort1.Write("v")
        Button12.Enabled = True
        Button11.Enabled = False
    End Sub
    Function apagados()
        Button1.BackColor = Color.Red
        SerialPort1.Write("b")
        Button2.BackColor = Color.Red
        SerialPort1.Write("d")
        Button3.BackColor = Color.Red
        SerialPort1.Write("f")
        Button4.BackColor = Color.Red
        SerialPort1.Write("h")
        Button5.BackColor = Color.Red
        SerialPort1.Write("j")
        Button6.BackColor = Color.Red
        SerialPort1.Write("l")
        Button8.BackColor = Color.Red
        SerialPort1.Write("p")
        Button9.BackColor = Color.Red
        SerialPort1.Write("r")
        Button10.BackColor = Color.Red
        SerialPort1.Write("t")

        Button12.Enabled = False
        Button11.Enabled = True
    End Function

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        apagados()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim salida As String
        salida = MsgBox("Deseas salir del sistema", vbYesNo + vbInformation, "Salida del sistema")
        If salida = vbYes Then
            End
        End If
    End Sub


End Class
