﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(76, 11)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 92)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "LED1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(188, 11)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(106, 90)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "LED 2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(300, 11)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(106, 90)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "LED 3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(412, 11)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(102, 88)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "LED4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(520, 10)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(102, 89)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "LED5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(128, 109)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(106, 90)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "LED6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(240, 107)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(106, 90)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "LED7"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(352, 109)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(102, 90)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "LED8"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(460, 107)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(102, 90)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "LED9"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM5"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(76, 235)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(158, 77)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "ENCENDER TODOS"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(272, 235)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(158, 77)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "APAGAR TODOS"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(459, 235)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(163, 77)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "SALIR"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 346)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ENCENDIDO DE LED´S"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
End Class
