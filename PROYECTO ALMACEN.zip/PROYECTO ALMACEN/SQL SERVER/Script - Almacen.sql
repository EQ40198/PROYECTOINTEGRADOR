----------------------------------------
-- Base de datos : Almac�n
-- Fecha : 19-11-2022
-- Autor : Remigio Huarcaya Almeyda
--         www.rhsoftperu.com
----------------------------------------
use master
go
if exists(select * from sysdatabases where name='Almacen')
	begin
		drop database Almacen
	end
CREATE DATABASE Almacen
go

USE Almacen
GO
CREATE TABLE distritos
(
id_dis int primary key identity (1,1),
nom_dis varchar(40) not null,
cod_postal char(5)
);
go

CREATE TABLE clientes
(
id_cli int primary key identity (1,1),
tip_doc char (10) not null,
nro_doc char(7) not null,
nom_cli varchar(40) not null,
ape_cli varchar(40) not null,
dir_cli varchar(40) not null,
id_dis int not null references distritos,
tel_cli char(9) not null,
correo_cli varchar(20) not null,
);
go

CREATE TABLE proveedores
(
id_prov int primary key identity (1,1),
ruc_prov char(11) not null unique,
nom_prov varchar(40) not null,
dir_prov varchar(40) not null,
tel_prov varchar (9) not null,
region char(1) not null check(region='L' or region='P'), -- Lima o Provincia
correo_prov varchar(40) not null,
logo image,
est_prov char(1) not null default 'A'
);
go
CREATE TABLE areas
(
id_area int primary key identity (1,1),
nom_area varchar(40) not null,
);
go
insert into areas values ('Producci�n')
insert into areas values ('Contabilidad')
insert into areas values ('Gerencia general')
insert into areas values ('Finanzas')
insert into areas values ('Mantenimiento')
insert into areas values ('Compras')
go

CREATE TABLE documentos
(
id_doc int primary key identity (1,1),
nom_doc varchar(40) not null,
nro_doc char(7) not null
);
go
insert into documentos values ('Guia de Ingreso','0000001')
insert into documentos values ('Guia de Salida','0000001')
insert into documentos values ('Guia de Remisi�n','0000004')
go

CREATE TABLE cargos
(
id_cargo int primary key identity (1,1),
nom_cargo varchar(40) not null,
);
go
insert into cargos values ('Jefe de almac�n')
insert into cargos values ('Asistente')
insert into cargos values ('Operador montacarga')
insert into cargos values ('Operador de c�mputo')
insert into cargos values ('Kardista')
insert into cargos values ('Limpieza')
go

CREATE TABLE categorias
(
id_cat int primary key identity (1,1),
nom_cat varchar(40) not null,
);

go
insert into categorias values ('Abarrotes')
insert into categorias values ('Electrodom�sticos')
insert into categorias values ('L�cteos')
insert into categorias values ('Jugueter�a')
go

CREATE TABLE subcategoria
(
id_subcat int primary key identity (1,1),
nom_subcat varchar(40) not null,
id_cat int references categorias
);
go

CREATE TABLE marcas
(
id_marca int primary key identity (1,1),
nombre varchar(20) not null,
)
insert into marcas values ('Basa')
insert into marcas values ('Donofrio')
insert into marcas values ('LG')
insert into marcas values ('Gloria')
insert into marcas values ('Basa')
go

CREATE TABLE presentacion
(
id_pres int primary key identity (1,1),
nom_pres varchar(20) not null,
)

CREATE TABLE productos 
(
id_pro int primary key identity (1,1),
nom_pro varchar(40) not null,
id_subcat int references subcategoria, 
id_marca int references marcas,
id_pres int references presentacion,
stk_actual int not null,
stk_max int not null check(stk_max >0),
img_pro image, -- foto
pre_pro decimal(7,2) not null check(pre_pro>0),
ubi_pro char(6) not null,  -- A2 01 02  ubicaci�n en almac�n
est_pro char(1) not null check(est_pro='A' or est_pro='D')
);
go

CREATE TABLE empleados
(
id_emp int primary key identity (1,1),
nom_emp varchar(40) not null,
ape_emp varchar(40) not null,
dir_emp varchar(40) not null,
tel_emp char(9) not null,
id_car int references cargos,
usu_emp varchar(12) not null,
pwd_emp varchar(12) not null,
est_emp char(1) not null check(est_emp='A' or est_emp='V' or est_emp='C')
);
go

create table transaccion
(
	id_tra int primary key identity(1,1),
	nom_tra varchar(50) not null,
	tipo_tra char(1) not null check(tipo_tra='I' or tipo_tra='S'),
	estado char(1)
)
go
insert into transaccion values ('Ingreso por compra','I', 'A')
insert into transaccion values ('Ingreso por ajuste de inventario','I', 'A')
insert into transaccion values ('Ingreso por devoluci�n','I', 'A')
insert into transaccion values ('Salida por requisici�n','S', 'A')
insert into transaccion values ('Salida por ajuste de inventario','S', 'A')
insert into transaccion values ('Salida por donaci�n','S', 'A')
insert into transaccion values ('Salida por reparaci�n','S', 'A')
go

create table motivos
(
id_mot int primary key identity (1,1),
des_mot varchar(200) not null
);
go
insert into motivos values ('Venta')
insert into motivos values ('Venta sujeta a confirmaci�n del comprador')
insert into motivos values ('Compra')
insert into motivos values ('Consignaci�n')
insert into motivos values ('Devoluci�n')
insert into motivos values ('Traslado entre establecimientos de la misma empresa')
insert into motivos values ('Traslado por emisor itinerante de comprobante de pagos')
insert into motivos values ('Recojo de bienes')
insert into motivos values ('Importaci�n')
insert into motivos values ('Traslado zona primaria')
insert into motivos values ('Exportaci�n')
insert into motivos values ('Venta a terceros')
go

create table transportistas
(
	id_trans int primary key identity (1,1),
	ruc_trans char(8) not null unique, 
	nom_trans varchar(25) not null,
	nro_placa char(7) not null,
	nro_lic char(7) not null
)
go

CREATE TABLE guias
(
id_guia int primary key identity (1,1),
id_doc int references documentos,
nro_doc char(7) not null,
fec_guia date not null default getdate(),
id_tra int not null references transaccion,
id_emp int not null references empleados,
obser_guia varchar(350) not null, -- Observaci�n
estado char(1) check(estado='A' or estado='X')
);
go
create table guia_ingreso
(
	id_guia int references guias,
	id_prov int references proveedores,
	doc_ref varchar(30) not null
);
go
create table guia_salida
(
	id_guia int references guias,
	id_area int references areas,
	doc_ref varchar(30) not null
);
go
create table guia_remision
(
	id_guia int references guias,
	id_cliente int references clientes,
	pto_partida varchar(45) not null,
	pto_llegada varchar(45) not null,
	id_mot int references motivos,
	id_trans int not null references transportistas,
);
go

create table detalle_guia
(
	id_det int primary key identity (1,1),
	id_guia int,
	id_pro int,
	can_pro int not null check(can_pro>0),
	obs_pro varchar(300),
	foreign key (id_pro) references productos(id_pro),
	foreign key (id_guia) references guias(id_guia),
	estado char(1)
);
go

